// Simulation de moteur pas à pas avec capacité
// de microstepping

// REQUIRED :
// "math.h"
// "graphics.h"
// "pulsefilter.h"

class MStepper {
	PulseFilterT FA1, FB1, FA2, FB2;

	uint poles = 4;
	bool bipolar = false;
	double inertia = 10;
	double friction = 2;
	uint linked_value = 1000;

	double angle = 0;
	double speed = 0;
	double t_last;
	
	bool physics = false;

	array<double> v;

	MStepper() {
	}

	void reset() {
		angle = 0.0;
		t_last = time();

		FA1 = PulseFilterT();
		FA2 = PulseFilterT();
		FB1 = PulseFilterT();
		FB2 = PulseFilterT();
		
		v.resize(4);
    }

	void updateStep() {
		double a = angleDiff(angle, 0);
		double p2 = 2.0*PI;
		double a2 = (a<0)? p2+a:a;
		uint ia = uint(linked_value*a2/p2);
		component.setLinkedValue(0, double(ia), 0);
		component.setLinkedString(1, ""+(a*180.0/PI), 0);
	}

	void newValues( double t, double a1, double a2, 
		double b1, double b2, double com ) {

		double va1, va2, vb1, vb2;
		if (bipolar) {
			double dv = a1 - a2;
			va1 = dv/2;
			va2 = -dv/2;
			dv = b1 - b2;
			vb1 = dv/2;
			vb2 = -dv/2;
		} else {
			va1 = a1 - com;
			vb1 = b1 - com;
			va2 = a2 - com;
			vb2 = b2 - com;
		}
		v[0] = FA1.f(va1, t);
		v[1] = FB1.f(vb1, t);
		v[2] = FA2.f(va2, t);
		v[3] = FB2.f(vb2, t);
	}


	void update( double t ) {
		string debug = "";
		double dt = t - t_last;

		double da = 2.0*PI/(4*poles);
		double a1, a2;

		array<double> a;	// poles index
		array<double> va;	// poles angle
		uint n = v.length();
		a.resize(n);
		va.resize(n);

		// Déterminer les poles
		uint p_count = 0;
		double rg;
		if (bipolar) {
			rg = 1.0;
		} else {
			rg = (poles > 1)? 2.1 : 1.9;
		}
		a1 = angle - da*rg;
		a2 = angle + da*rg;
		int ia=ceil(a1/da);
		while (ia <= a2/da) {
			a[p_count] = ia*da;
			va[p_count] = v[modulo4(ia)];
			p_count++;
			ia++;
		}

		// Calculer le baricentre (pole dominant)
		double torque = 0;
		double bc = 0;
		double w = 0;
		for (uint i=0; i<p_count; i++) {
			bc += va[i]*a[i];
			w += va[i];
		}

		// Si poids non nul, alors pole dominant
		if (w > 0.0000000001) {
			bc = bc / w;
			// Se deplacer vers pole dominant
			double anglediff = NormalizeAngle(bc-angle);
			torque = anglediff*w;
		}
		double acc = torque/inertia;
		speed += (acc-friction*speed)*dt;
		angle += speed*dt;
		if (!physics) {
			speed = 0;
		}

		t_last = t;
		
		this.updateStep();
	}
	
	void draw() {
		clear();
		screen.setBackground(0x7070A0);

		double x0 = width/2;
		double y0 = height/2;

		double rr = width/2*0.85;
		double rr2 = rr*1.1;
		double rs = width/2*0.8;

		drawStator(x0, y0, rr, rr2, poles, 0xFFFFFF);
		drawRotor(x0, y0, rs, 0xFFFF00);
	}


	void drawStatorOnePole( double xc, double yc, double r1, double r2, double a1, double a2, uint color ) {
		double da = (a2-a1)/16;
		int n = 3;
		for (int i=0; i<16; i++) {
			double r = (n < 2)? r2 : r1;
			drawArc(xc, yc, r, a1+i*da, a1+(i+1)*da, color);
			if ((n == 0) || (n == 2)) {
				double c = cos(a1+i*da);
				double s = sin(a1+i*da);
				double x1 = xc+r1*c;
				double y1 = yc-r1*s;
				double x2 = xc+r2*c;
				double y2 = yc-r2*s;
				drawLine(x1, y1, x2, y2, color);
			}
			n = (n+1)%4;
		}
	}


	void drawStator( double xc, double yc, double r1, double r2, int N, uint color ) {
		double da = PI*2/N;
		for (double a=0; a<PI*2; a+=da) {
			drawStatorOnePole(xc, yc, r1, r2, a, a+da, color);
		}
	}


	void drawRotor( double xc, double yc, double r, uint color ) {
		drawArc(xc, yc, r, 0, PI, color);
		drawArc(xc, yc, r, PI, PI*2.0, color);
		drawArc(xc, yc, r/6, 0, PI, color);
		drawArc(xc, yc, r/6, PI, PI*2.0, color);
		double x1 = xc + r*cos(angle);
		double y1 = yc - r*sin(angle);
		double x2 = xc + r*cos(angle+PI+20*PI/180);
		double y2 = yc - r*sin(angle+PI+20*PI/180);
		double x3 = xc + r*cos(angle+PI-20*PI/180);
		double y3 = yc - r*sin(angle+PI-20*PI/180);
		drawLine(x1, y1, x2, y2, color);
		drawLine(x2, y2, x3, y3, color);
		drawLine(x3, y3, x1, y1, color);
	}

	int modulo4( int i ) {
		while (i < 0) i += 4;
		return i % 4;
	}

	double angleDiff( double a, double b ) {
		// différence d'angles -PI à +PI
		double diff = a - b;
		while (diff <= -PI) diff += 2.0 * PI;
		while (diff > PI) diff -= 2.0 * PI;
		return diff;
	}
}
