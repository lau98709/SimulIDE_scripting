// Simulation de moteur pas à pas avec capacité
// de microstepping

// REQUIRED :
// "math.h"
// "graphics.h"
// "pulsefilter.h"

class MStepper {
	uint poles = 4;
	bool bipolar = false;
	double inertia = 10;
	double friction = 2;
	uint linked_value = 1000;

	double angle = 0;
	double speed = 0;
	double t_last;
	
	bool physics = false;

	double v_a1, v_b1, v_a2, v_b2;

	MStepper() {
		angle = 0.0;
		t_last = time();	
	}
}

void stepperUpdateStep( MStepper@ m ) {
	double a = angleDiff(m.angle, 0);
	double p2 = 2.0*PI;
	double a2 = (a<0)? p2+a:a;
	uint ia = uint(m.linked_value*a2/p2);
	component.setLinkedValue(0, double(ia), 0);
	component.setLinkedString(1, ""+(a*180.0/PI), 0);
}

void stepperNewValues( MStepper@ m, double t, double a1, double a2, double b1, double b2, double com ) {
	double va1, va2, vb1, vb2;
	
	if (m.bipolar) {
		double dv = a1 - a2;
		va1 = dv/2;
		va2 = -dv/2;
		dv = b1 - b2;
		vb1 = dv/2;
		vb2 = -dv/2;
	} else {
		va1 = a1 - com;
		vb1 = b1 - com;
		va2 = a2 - com;
		vb2 = b2 - com;
	}

	m.v_a1 = va1;
	m.v_b1 = vb1;
	m.v_a2 = va2;
	m.v_b2 = vb2;
}


double poleVoltage( MStepper@ m, uint i ) {
	uint i4 = modulo4(i);
	if (i4 == 0) return m.v_a1;
	if (i4 == 1) return m.v_b1;
	if (i4 == 2) return m.v_a2;
	if (i4 == 3) return m.v_b2;
	return 0;
}


void stepperUpdate( MStepper@ m, double t ) {
	string debug = "";
	double dt = t - m.t_last;

	double da = 2.0*PI/(4*m.poles);
	double a1, a2;

	array<double> a;	// m.poles index
	array<double> va;	// m.poles m.angle

	// Déterminer les m.poles
	uint p_count = 0;
	double rg;
	if (m.bipolar) {
		rg = 1.0;
	} else {
		rg = (m.poles > 1)? 2.1 : 1.9;
	}
	a1 = m.angle - da*rg;
	a2 = m.angle + da*rg;
	int ia=ceil(a1/da);
	while (ia <= a2/da) {
		a.insertLast(ia*da);
		va.insertLast(poleVoltage(m, ia));
		p_count++;
		ia++;
	}

	// Calculer le baricentre (pole dominant)
	double torque = 0;
	double bc = 0;
	double w = 0;
	for (uint i=0; i<a.length(); i++) {
		bc += va[i]*a[i];
		w += va[i];
	}

	// Si poids non nul, alors pole dominant
	if (w > 0.0000000001) {
		bc = bc / w;
		// Se deplacer vers pole dominant
		double dangle = NormalizeAngle(bc-m.angle);
		torque = dangle*w;
	}
	double acc = torque/m.inertia;
	m.speed += (acc-m.friction*m.speed)*dt;
	m.angle += m.speed*dt;
	if (!m.physics) {
		m.speed = 0;
	}

	m.t_last = t;
	
	stepperUpdateStep(m);
}

void stepperDraw(MStepper &in m, int width, int height) {
	clear();
	screen.setBackground(0x7070A0);

	double x0 = width/2;
	double y0 = height/2;

	double rr = width/2*0.85;
	double rr2 = rr*1.1;
	double rs = width/2*0.8;

	stepperDrawStator(x0, y0, rr, rr2, m.poles, 0xFFFFFF);
	stepperDrawRotor(x0, y0, rs, m.angle, 0xFFFF00);
}


void stepperDrawStatorOnePole( double xc, double yc, double r1, double r2, double a1, double a2, uint color ) {
	double da = (a2-a1)/16;
	int n = 3;
	for (int i=0; i<16; i++) {
		double r = (n < 2)? r2 : r1;
		drawArc(xc, yc, r, a1+i*da, a1+(i+1)*da, color);
		if ((n == 0) || (n == 2)) {
			double c = cos(a1+i*da);
			double s = sin(a1+i*da);
			double x1 = xc+r1*c;
			double y1 = yc-r1*s;
			double x2 = xc+r2*c;
			double y2 = yc-r2*s;
			drawLine(x1, y1, x2, y2, color);
		}
		n = (n+1)%4;
	}
}


void stepperDrawStator( double xc, double yc, double r1, double r2, int N, uint color ) {
	double da = PI*2/N;
	for (double a=0; a<PI*2; a+=da) {
		stepperDrawStatorOnePole(xc, yc, r1, r2, a, a+da, color);
	}
}


void stepperDrawRotor( double xc, double yc, double r, double angle, uint color ) {
	drawArc(xc, yc, r, 0, PI, color);
	drawArc(xc, yc, r, PI, PI*2.0, color);
	drawArc(xc, yc, r/6, 0, PI, color);
	drawArc(xc, yc, r/6, PI, PI*2.0, color);
	double x1 = xc + r*cos(angle);
	double y1 = yc - r*sin(angle);
	double x2 = xc + r*cos(angle+PI+20*PI/180);
	double y2 = yc - r*sin(angle+PI+20*PI/180);
	double x3 = xc + r*cos(angle+PI-20*PI/180);
	double y3 = yc - r*sin(angle+PI-20*PI/180);
	drawLine(x1, y1, x2, y2, color);
	drawLine(x2, y2, x3, y3, color);
	drawLine(x3, y3, x1, y1, color);
}

int modulo4( int i ) {
	while (i < 0) i += 4;
	return i % 4;
}
